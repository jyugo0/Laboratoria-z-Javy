package pwr.karmil.lab07catering.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;
import java.util.List;

public class OrderRequest {
    @Schema(example = "user", description = "Nazwa zamawiającego użytkownika")
    private Integer username;
    @Schema(example = "14-05-2026 16:00:00", description = "Data na którą ma być dostarczone zamówienie")
    private Instant deliveryDate;

    private List<ElementsSelection> items;

    public OrderRequest() {}

    public Integer getUsername() { return username; }
    public void setUsername(Integer username) { this.username = username; }

    public Instant getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(Instant deliveryDate) { this.deliveryDate = deliveryDate; }

    public List<ElementsSelection> getItems() { return items; }
    public void setItems(List<ElementsSelection> items) { this.items = items; }
}
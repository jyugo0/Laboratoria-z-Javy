package pwr.karmil.lab07catering.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pwr.karmil.lab07catering.database.OrderElement;
import pwr.karmil.lab07catering.database.OrderElementRepository;

import java.util.List;

@RestController
@RequestMapping("/api/order-elements")
public class OrderElementController {

    @Autowired
    private OrderElementRepository orderElementRepository;

    @GetMapping
    public List<OrderElement> getAllOrderElements() {
        return orderElementRepository.findAll();
    }

    @PostMapping
    public OrderElement createOrderElement(@RequestBody OrderElement orderElement) {
        return orderElementRepository.save(orderElement);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrderElement(@PathVariable Integer id) {
        return orderElementRepository.findById(id).map(element -> {
            orderElementRepository.delete(element);
            return ResponseEntity.ok().<Void>build();
        }).orElse(ResponseEntity.notFound().build());
    }
}

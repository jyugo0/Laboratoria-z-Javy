package pwr.karmil.lab07catering.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pwr.karmil.lab07catering.database.Order;
import pwr.karmil.lab07catering.database.OrderRepository;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/simulation")
public class SimController {

    @Autowired
    private OrderRepository orderRepository;

    @PostMapping("/set-time")
    public ResponseEntity<String> setTime(@RequestParam String date) {
        Instant setDate = Instant.parse(date); // lub użyj LocalDate
        List<Order> orders = orderRepository.findAll();

        for (Order order : orders) {
            if ("ZAPLACONE".equals(order.getState()) && order.getDate().isBefore(setDate)) {
                order.setState("DOSTARCZONE");
                orderRepository.save(order);
            }
        }
        return ResponseEntity.ok("Symulacja czasu udana");
    }
}
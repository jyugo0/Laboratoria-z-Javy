package pwr.karmil.lab07catering.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pwr.karmil.lab07catering.database.Order;
import pwr.karmil.lab07catering.database.OrderRepository;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private OrderRepository orderRepository;

    @PutMapping("/orders/{id}/accept-payment")
    public ResponseEntity<Order> acceptPayment(@PathVariable Integer id) {
        return orderRepository.findById(id).map(order -> {
            order.setState("ZAPLACONE");
            return ResponseEntity.ok(orderRepository.save(order));
        }).orElse(ResponseEntity.notFound().build());
    }
}

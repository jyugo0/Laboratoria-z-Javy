package pwr.karmil.lab07catering.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pwr.karmil.lab07catering.database.*;
import pwr.karmil.lab07catering.dto.ElementsSelection;
import pwr.karmil.lab07catering.dto.OrderRequest;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired private OrderRepository orderRepository;
    @Autowired private MenuRepository menuRepository;
    @Autowired private OrderElementRepository orderElementRepository;
    @Autowired private UserRepository userRepository;

    @PostMapping("/place-order")
    public ResponseEntity<?> placeOrder(@RequestBody OrderRequest dto) {
        // 1. Szukamy użytkownika po nazwie
        User user = userRepository.findByUsername(String.valueOf(dto.getUsername()))
                .orElseThrow(() -> new RuntimeException("Nie znaleziono użytkownika: " + dto.getUsername()));

        Order order = new Order();
        order.setUser(user);
        order.setState("NIEOPLACONE");
        order.setDate(dto.getDeliveryDate());

        BigDecimal total = BigDecimal.ZERO;
        List<OrderElement> elements = new ArrayList<>();

        // 2. Przetwarzamy listę dań po nazwach
        for (ElementsSelection selection : dto.getItems()) {
            Menu menu = menuRepository.findByName(String.valueOf(selection.getMenuName()))
                    .orElseThrow(() -> new RuntimeException("Nie ma w menu: " + selection.getMenuName()));

            BigDecimal itemCost = BigDecimal.valueOf(menu.getPrice())
                    .multiply(BigDecimal.valueOf(selection.getQuantity()));
            total = total.add(itemCost);

            OrderElement el = new OrderElement();
            el.setItem(menu);
            el.setHowMany(selection.getQuantity());
            el.setOrder(order);
            elements.add(el);
        }

        order.setCost(total);
        Order savedOrder = orderRepository.save(order);
        orderElementRepository.saveAll(elements);

        return ResponseEntity.ok(savedOrder);
    }

    @PutMapping("/{id}/pay")
    public ResponseEntity<Order> pay(@PathVariable Integer id) {
        return orderRepository.findById(id).map(order -> {
            if ("NIEOPLACONE".equals(order.getState())) {
                order.setState("OCZEKIWANIE");
                return ResponseEntity.ok(orderRepository.save(order));
            }
            return ResponseEntity.badRequest().<Order>build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
